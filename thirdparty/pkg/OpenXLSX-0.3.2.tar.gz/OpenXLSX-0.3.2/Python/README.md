# OpenXLSX for Python

OpenXLSX is a C++ library for reading, writing, creating and modifying
Microsoft Excel® files, with the .xlsx format.

## Table of Contents


## Motivation

There are plenty of python packages for manipulating Excel workbooks. So
why another one?

## Compatibility


## Build Instructions


## Example Programs

